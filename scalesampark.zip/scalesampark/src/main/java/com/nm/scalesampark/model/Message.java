package com.nm.scalesampark.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.nm.scalesampark.util.AES;

@Entity
@Table(name = "message")
public class Message implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column
	private String message;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name= "message_type")
	private MessageType messageType;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name= "sender_id", nullable = false)
	private Participant senderId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name= "reciever_id")
	private Participant recieverId;

	@Column(name="created_time")
	private Date createdTime;
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMessage() {
		return AES.decrypt(message);
	}

	public void setMessage(String message) {
		this.message = AES.encrypt(message);
	}

	public MessageType getMessageType() {
		return messageType;
	}

	public void setMessageType(MessageType messageType) {
		this.messageType = messageType;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Participant getSenderId() {
		return senderId;
	}

	public void setSenderId(Participant senderId) {
		this.senderId = senderId;
	}

	public Participant getRecieverId() {
		return recieverId;
	}

	public void setRecieverId(Participant recieverId) {
		this.recieverId = recieverId;
	}
	
}
