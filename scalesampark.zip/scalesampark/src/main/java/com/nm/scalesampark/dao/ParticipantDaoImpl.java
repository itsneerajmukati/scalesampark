package com.nm.scalesampark.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nm.scalesampark.model.Participant;

@Repository
public class ParticipantDaoImpl implements ParticipantDao {
	
	@Autowired
	EntityManager entityManager;

	@Override
	public Participant create(Participant participant) {
		return entityManager.merge(participant);
	}

	@Override
	public List<Participant> findAll() {
		Query query = entityManager.createQuery("select p from Participant p", Participant.class);
		return query.getResultList();
	}
	
	@Override
	public Participant findById(Integer participantId) {
		Query query = entityManager.createQuery("select p from Participant p where p.id=:participantId", Participant.class);
		query.setParameter("participantId", participantId);
		return (Participant) query.getResultList().get(0);
	}
	
	public Participant updateLastSeen(Participant participant) {
		return entityManager.merge(participant);
	}

	@Override
	public void deregisterParticipant(Integer id) {
		Participant participant = findById(id);
		entityManager.remove(participant);
		/*
		 * Query query =
		 * entityManager.createQuery("delete from Participant p where p.id = :id");
		 * query.setParameter("id", id); query.executeUpdate();
		 */
	}
	
	
}
