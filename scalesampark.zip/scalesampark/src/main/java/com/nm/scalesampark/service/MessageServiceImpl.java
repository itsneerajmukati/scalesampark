package com.nm.scalesampark.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nm.scalesampark.dao.MessageDao;
import com.nm.scalesampark.dao.ParticipantDao;
import com.nm.scalesampark.model.Message;
import com.nm.scalesampark.model.Participant;

@Service
@Transactional
public class MessageServiceImpl implements MessageService {

	@Autowired
	private MessageDao messageDao;
	
	@Autowired
	private ParticipantDao participantDao; 
	
	@Override
	public Message sendMessageToAll(Message message) {
		message.setCreatedTime(new Date());
		return messageDao.create(message);
	}
	
	@Override
	public Message sendMessageToOne(Message message) {
		message.setCreatedTime(new Date());
		return messageDao.create(message);
	}

	@Override
	public List<Message> retrievePendingMessage(Integer participantId) {
		Participant participant = participantDao.findById(participantId);
		List<Message> messages = messageDao.retrievePendingMessage(participantId,participant.getLastSeen());
		participant.setLastSeen(new Date());
		participantDao.updateLastSeen(participant);
		return messages;
	}
	
	
	
}
