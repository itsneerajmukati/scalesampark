package com.nm.scalesampark.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nm.scalesampark.model.Message;
import com.nm.scalesampark.model.Participant;

@Repository
public class MessageDaoImpl implements MessageDao {
	
	@Autowired
	EntityManager entityManager;

	@Override
	public Message create(Message message) {
		return entityManager.merge(message);
	}

	@Override
	public List<Message> findAll() {
		Query query = entityManager.createQuery("select m from Message m", Message.class);
		return query.getResultList();
	}

	@Override
	public List<Message> retrievePendingMessage(Integer participantId, Date date) {
		Query query = entityManager.createQuery("select m from Message m where (m.recieverId.id=:participantId or m.recieverId.id is null) and m.createdTime > :date and m.senderId.id != :participantId", Message.class);
		query.setParameter("participantId", participantId);
		query.setParameter("date", date);
		return query.getResultList();
	}

	@Override
	public void removeMessageByParticipantId(Integer id) {
		Query query = entityManager.createQuery("delete from Message m where m.senderId.id=:id or m.recieverId.id=:id");
		query.setParameter("id", id);
		query.executeUpdate();
	}
	
	
}
