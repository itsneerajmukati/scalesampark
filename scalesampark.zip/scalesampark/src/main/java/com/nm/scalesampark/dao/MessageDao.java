package com.nm.scalesampark.dao;

import java.util.Date;
import java.util.List;

import com.nm.scalesampark.model.Message;

public interface MessageDao {
	
	public Message create(Message message);
	
	public List<Message> findAll();
	
	public List<Message> retrievePendingMessage(Integer participantId,Date date);
	
	public void removeMessageByParticipantId(Integer id);

}
