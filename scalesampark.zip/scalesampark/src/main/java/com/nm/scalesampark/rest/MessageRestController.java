package com.nm.scalesampark.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nm.scalesampark.model.Message;
import com.nm.scalesampark.model.Participant;
import com.nm.scalesampark.service.MessageService;

@RestController
@RequestMapping("/message")
public class MessageRestController {
	
	@Autowired
	private MessageService messageService;

	@PostMapping("/send-message")
	public ResponseEntity<Message> sendMessageToAll(@RequestBody Message message) {
		try {
			Message response = messageService.sendMessageToAll(message);
			return new ResponseEntity<Message>(response, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Message>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/send-message-to-one")
	public ResponseEntity<Message> sendMessageToOne(@RequestBody Message message) {
		try {
			Message response = messageService.sendMessageToOne(message);
			return new ResponseEntity<Message>(response, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Message>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@RequestMapping("retrive-pending-message")
	public ResponseEntity<List<Message>> retrievePendingMessage(@RequestParam("participantId") Integer participantId) {
		try {
			List<Message> response = messageService.retrievePendingMessage(participantId);
			return new ResponseEntity<List<Message>>(response, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<List<Message>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
}
