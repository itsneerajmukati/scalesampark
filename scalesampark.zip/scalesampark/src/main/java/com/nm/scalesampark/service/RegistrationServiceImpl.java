package com.nm.scalesampark.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nm.scalesampark.dao.MessageDao;
import com.nm.scalesampark.dao.ParticipantDao;
import com.nm.scalesampark.model.Participant;

@Transactional
@Service
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	ParticipantDao participantDao;
	
	@Autowired
	MessageDao messageDao;
	
	@Override
	public Participant registerParticipant(Participant participant) {
		participant.setLastSeen(new Date());
		return participantDao.create(participant);
	}

	@Override
	public List<Participant> findAll() {
		return participantDao.findAll();
	}

	@Override
	public String deregisterParticipant(Integer id) {
		messageDao.removeMessageByParticipantId(id);
		participantDao.deregisterParticipant(id);
		return "Success";
	}
	

}
