package com.nm.scalesampark.rest;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nm.scalesampark.model.Participant;
import com.nm.scalesampark.service.RegistrationService;

@RestController
@RequestMapping("/participant")
public class RegistrationRestController {
	
	@Autowired
	private RegistrationService registrationService;
	
	@PostMapping("/register")
	public ResponseEntity<Participant> registerParticipant(@RequestBody Participant participant) {
		try {
			Participant response = registrationService.registerParticipant(participant);
			return new ResponseEntity<Participant>(response, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<Participant>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping(value =  "/deregister/{id}")
	public ResponseEntity<String> deregisterParticipant(@PathVariable(value = "id") Integer id) {
		try {
			registrationService.deregisterParticipant(id);
			return new ResponseEntity<String>("Success", HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@RequestMapping("/findAll")
	public ResponseEntity<List<Participant>> findAll() {
		try {
			List<Participant> response = registrationService.findAll();
			return new ResponseEntity<>(response, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	

}
