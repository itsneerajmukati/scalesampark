package com.nm.scalesampark.service;

import java.util.List;

import com.nm.scalesampark.model.Message;

public interface MessageService {
	
	public Message sendMessageToAll(Message message);
	
	public Message sendMessageToOne(Message message);
	
	public List<Message> retrievePendingMessage(Integer participantId);
}
