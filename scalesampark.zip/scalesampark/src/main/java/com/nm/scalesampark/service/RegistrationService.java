package com.nm.scalesampark.service;

import java.util.List;

import com.nm.scalesampark.model.Participant;

public interface RegistrationService {
	
	public Participant registerParticipant(Participant participant);
	
	public String deregisterParticipant(Integer id);
	
	public List<Participant> findAll();

}
