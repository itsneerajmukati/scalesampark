package com.nm.scalesampark.dao;

import java.util.List;

import com.nm.scalesampark.model.Participant;

public interface ParticipantDao {
	
	public Participant create(Participant participant);
	
	public List<Participant> findAll();
	
	public Participant updateLastSeen(Participant participant);
	
	public Participant findById(Integer participantId);
	
	public void deregisterParticipant(Integer id);

}
